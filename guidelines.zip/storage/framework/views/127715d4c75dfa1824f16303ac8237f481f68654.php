<?php echo $__env->make('base.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="guidelines_admin" data-content="<?php echo e(Route('logo')); ?>">
    <div class="task_bar">
        <div class="logo">
            <a href="<?php echo e(asset('/admin')); ?>"><img src="images/logo.png" alt="logo"></a>
        </div>

        <div class="info">
            <div class="img"><img src="images/avatar.jpg" alt="avatar"></div>

            <div class="logout">
                <span>Hello | </span>
                <a href="<?php echo e(Route('checkLogout')); ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
            </div>

            <div class="name"><?php echo e(Session::get('session_guideline_username')); ?></div>
        </div>

        <div class="menu">
            <ul>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-industry" aria-hidden="true"></i>Project</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-users"></i>People</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-bell-o" aria-hidden="true"></i>Activity <sup id="count_noti" style="color:#f00;">(5)</sup></a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-info-circle" aria-hidden="true"></i>Tutorial</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-book" aria-hidden="true"></i>Rules</a></li>
                <li class="current-menu-item"><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-hdd-o" aria-hidden="true"></i>Storage</a></li>
                <li class="active"><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-book" aria-hidden="true"></i>Guidelines</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-cog"></i>Setting</a></li>
            </ul>
        </div>
    </div>
    <div class="main_content">
        <div class="search">
            <form action="search.php" method="post">
                <input type="text" name="keyword" placeholder="Search..." data-url="<?php echo e(Route('ajax-search-project')); ?>" data-invite="<?php echo e(Route('ajax-invite')); ?>">
                <button name="sub_search" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>

        <div class="nav_head">
            <h1>Guidelines Online</h1>
            <div class="flex-grow"></div>
            <ul>
                <li class="active"><a href="<?php echo e(asset('/admin#')); ?>"></a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><span></span>Available</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><span></span>Process</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><span></span>Used</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><span></span>Pending</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-minus-circle" aria-hidden="true"></i> Canceled</a></li>
                <li><a href="<?php echo e(asset('/admin#')); ?>"><i class="fa fa-heart-o" aria-hidden="true"></i> Favorite</a></li>
            </ul>
        </div>

        <div class="filter">
            <button type="button" class="btn_create_item">+ Create new item</button>
        </div>

        <div class="list_guide">
            <div class="item">
                <div class="insider">
                    <?php
                        $errors = Session::get('errors');
                        if($errors){
                            echo '<p class="alert-danger" style="margin-top: -10px;">'.$errors.'</p>';
                        }
                    ?>
                    <table>
                        <thead>
                            <th>Project</th>
                            <th>Status</th>
                            <th>Start day</th>
                            <th>Create</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                            <?php if($projects_sk_count > 0): ?>
                                <?php $__currentLoopData = $projects_sk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $project_id = $project->name_project;
                                        $sec = $project->security;
                                     ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(asset($project->slug)); ?>" target="_blank" <?php if($sec == 1): ?> class="active" <?php endif; ?>>
                                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->project_id == $project_id): ?>
                                                        <strong>
                                                            <?php echo e($item->project_name); ?>

                                                            <?php if($sec == 1): ?>
                                                                <i class="fa fa-lock" aria-hidden="true"></i>
                                                            <?php endif; ?>
                                                        </strong>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </a>
                                        </td>
                                        <td>
                                            <?php if($project->status == 1): ?>
                                                <span class="process">Process</span>
                                            <?php elseif($project->status == 2): ?>
                                                <span class="done">done</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($project->created_at); ?></td>
                                        <td><?php echo e($project->name_create); ?></td>
                                        <td>
                                            <span class="add" data-id="<?php echo e($project->id); ?>" data-url="<?php echo e(Route('ajax-invite')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i></span>
                                            <a href="<?php echo e(asset($project->slug)); ?>" target="_blank"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr><td colspan="5">Dữ liệu trống !</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php if($projects_sk_count > 0): ?>
        <button type="button" class="loadmore"><span>Loadmore...</span><i class="fa fa-refresh" aria-hidden="true"></i></button>
        <?php endif; ?>
    </div>
</div>


<div class="new_guide">
    <form action="<?php echo e(asset('new/guidelines')); ?>" method="post">
        <div class="insider">
            <h2>Create new Guidelines</h2>
            <div class="close_guide"><img src="images/close.png" alt="close" /></div>
            <div class="form">
                <label>Project Name</label>
                <div class="invite_user_slt invite_user_slt1 invite_user_slt_project">
                    <div class="list_tags">
                        <div class="list">
                            <div class="insider insider1">
                                <span>Select users</span>
                            </div>
                        </div>
                        <div class="search_keyword_slt search_keyword_slt1">
                            <input type="text" class="get_slt_keyword get_slt_keyword1" placeholder="Search users...">
                            <div class="list_slt list_slt1">
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item" data-id="<?php echo e($project->project_id); ?>"><?php echo e($project->project_name); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="close_tag close_tag1"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                    </div>
                </div>
                <label>Invite users *:</label>
                <div class="invite_user_slt invite_user_slt2 invite_user_slt_user">
                    <div class="list_tags">
                        <div class="list">
                            <div class="insider insider2">
                                <span>Select users</span>
                            </div>
                        </div>
                        <div class="search_keyword_slt search_keyword_slt3">
                            <input type="text" class="get_slt_keyword get_slt_keyword2" placeholder="Search users...">
                            <div class="list_slt list_slt2">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item" data-id="<?php echo e($user->userid); ?>"><?php echo e($user->username); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="close_tag close_tag3"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                    </div>
                </div>
                <label>Categories *:</label>
                <div class="invite_user_slt invite_user_slt3 invite_user_slt_cate">
                    <div class="list_tags">
                        <div class="list">
                            <div class="insider insider3">
                                <span>Select categories</span>
                            </div>
                        </div>
                        <div class="search_keyword_slt">
                            <input type="text" class="get_slt_keyword get_slt_keyword3" placeholder="Search categories...">
                            <div class="list_slt list_slt3">
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item" data-id="<?php echo e($cate->category_id); ?>"><?php echo e($cate->category_name); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="close_tag close_tag2"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                    </div>
                </div>

                <input type="hidden" name="get_invite_user_slt_project" class="get_invite_user_slt_project">
                <input type="hidden" name="get_invite_user_slt_user" class="get_invite_user_slt_user">
                <input type="hidden" name="get_invite_user_slt_cate" class="get_invite_user_slt_cate">

                <div class="btn_create">
                    <div class="check_dk"><input type="checkbox" name="checkbox_project">Dự án yêu cầu về bảo mật thông tin <i class="fa fa-question-circle" aria-hidden="true"></i></div>
                    <button type="submit" class="create_guide_new">Create new Guidelines</button>
                </div>
            </div>
        </div>
        <?php echo e(csrf_field()); ?>

    </form>
</div>

<div class="invite_list">
    <div class="insider">
        <div class="close_guide"><img src="images/close.png" alt="close" /></div>
        <label>Invite users *:</label>
        <div class="invite_user_slt invite_user_slt2 invite_user_slt_user">
            <div class="list_tags">
                <div class="list">
                    <div class="insider insider2">
                        <span>Select users</span>
                    </div>
                </div>
                <div class="search_keyword_slt search_keyword_slt3">
                    <input type="text" class="get_slt_keyword get_slt_keyword2" placeholder="Search users...">
                    <div class="list_slt list_slt2">

                    </div>
                </div>
                <div class="close_tag close_tag3"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
            </div>
        </div>

        <input type="hidden" name="get_invite_user_slt_user" class="get_invite_user_slt_user">
        <input type="hidden" name="get_invite_id" class="get_invite_id">
        <input type="hidden" name="get_invite_url" class="get_invite_url" value="<?php echo e(Route('ajax-update-invite')); ?>">
    </div>
</div>

<?php echo $__env->make('base.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
