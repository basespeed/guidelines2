<section class="section section8">
    <div class="in">
        <h2>0.6 <p>Màu sắc hạn chế</p></h2>

        <div class="list_color">
            <div class="item">
                <div class="content">
                    <p>Màu sắc là yếu tố có ảnh hưởng lớn đến sức mạnh thương hiệu tổng thể. Sức mạnh của màu sắc quan trọng không kém hình dạng của biểu tượng, chính vì vậy màu đặc trưng phải được ưu tiên áp dụng để duy trì tính thống nhất của thương hiệu và hệ thống nhãn hiệu.</p>
                    <p>Màu sắc của Logo (phần hình và phần chữ) trong thương hiệu và tất cả các đơn vị không được phép thay đổi như đã quy định.</p>
                    <p>Các bảng màu của logo GS GROUP được lấy cảm hứng từ phong thủy và thực tế đời sống, phù hợp với chủ doanh nghiệp.</p>
                    <p>Chú ý:</p>
                    <p>- Khi sản xuất, in ấn liên quan đến màu sắc đặc trưng của logo trên các chất liệu khác nhau như: giấy, vải, gỗ, đá, kính, kim loại... cần đối chiếu với màu được quy chuẩn trong cuốn Guidelines này.</p>
                </div>
            </div>
            <div class="item">
                <div class="content">
                    <?php $__currentLoopData = $data_color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($color->layout_color == 8 && $color->color_menu == $id_menu_check || $color->layout_color == 8 && $color->color_menu_child == $id_menu_check): ?>
                    <div class="list_color">
                        <div class="list">
                            <?php if(isset($color->hex) && isset($color->hex2)): ?>
                            <div class="color_item" style="background-image: linear-gradient(to right, <?php echo e($color->hex); ?>, <?php echo e($color->hex2); ?>);"></div>
                            <?php else: ?>
                            <div class="color_item" style="background-image: linear-gradient(to right, #7b400a, #f67f13);"></div>
                            <?php endif; ?>
                        </div>
                        <div class="info">
                            <ul>
                                <?php if(isset($color->rgb)): ?>
                                <li>RGB: <?php echo e($color->rgb); ?></li>
                                <?php else: ?>
                                <li>RGB: 240   131  0</li>
                                <?php endif; ?>

                                <?php if(isset($color->cmyk)): ?>
                                <li>CMYK: <?php echo e($color->cmyk); ?></li>
                                <?php else: ?>
                                <li>CMYK: 0   57    100    0</li>
                                <?php endif; ?>

                                <?php if(isset($color->hex)): ?>
                                <li>HEX CODE: <?php echo e($color->hex); ?></li>
                                <?php else: ?>
                                <li>HEX CODE: #F08300</li>
                                <?php endif; ?>
                            </ul>
                            <div class="flex-grow"></div>
                            <ul>
                                <?php if(isset($color->rgb2)): ?>
                                <li>RGB: <?php echo e($color->rgb2); ?></li>
                                <?php else: ?>
                                <li>RGB: 240   131  0</li>
                                <?php endif; ?>

                                <?php if(isset($color->cmyk2)): ?>
                                <li>CMYK: <?php echo e($color->cmyk2); ?></li>
                                <?php else: ?>
                                <li>CMYK: 0   57    100    0</li>
                                <?php endif; ?>

                                <?php if(isset($color->hex2)): ?>
                                <li>HEX CODE: <?php echo e($color->hex2); ?></li>
                                <?php else: ?>
                                <li>HEX CODE: #F08300</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>