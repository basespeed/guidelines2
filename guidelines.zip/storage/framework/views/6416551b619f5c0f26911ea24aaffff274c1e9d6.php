<section data-id="<?php  if(isset($id_menu_check)){echo $id_menu_check;}  ?>" class="section section8">
    <input type="hidden" name="check_type_menu_layout8" class="check_type_menu_layout8" value="<?php echo e($check_menu); ?>">
    <div class="in">
        <h2>0.6 <p>Màu sắc chuyển</p></h2>

        <div class="list_color">
            <div class="item">
                <div class="content">
                    <p>Màu sắc là yếu tố có ảnh hưởng lớn đến sức mạnh thương hiệu tổng thể. Sức mạnh của màu sắc quan trọng không kém hình dạng của biểu tượng, chính vì vậy màu đặc trưng phải được ưu tiên áp dụng để duy trì tính thống nhất của thương hiệu và hệ thống nhãn hiệu.</p>
                    <p>Màu sắc của Logo (phần hình và phần chữ) trong thương hiệu và tất cả các đơn vị không được phép thay đổi như đã quy định.</p>
                    <p>Các bảng màu của logo GS GROUP được lấy cảm hứng từ phong thủy và thực tế đời sống, phù hợp với chủ doanh nghiệp.</p>
                    <p>Chú ý:</p>
                    <p>- Khi sản xuất, in ấn liên quan đến màu sắc đặc trưng của logo trên các chất liệu khác nhau như: giấy, vải, gỗ, đá, kính, kim loại... cần đối chiếu với màu được quy chuẩn trong cuốn Guidelines này.</p>
                </div>
            </div>
            <div class="item">
                <div class="content">
                    <?php 
                        $a = 0;
                        $b = 0;
                     ?>
                    <?php $__currentLoopData = $data_color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($data->color_menu == $id_menu_check || $data->color_menu_child == $id_menu_check): ?>
                            <?php 
                                $a++;
                                $b++;
                             ?>
                            <input type="hidden" name="insert_color<?php echo e($b); ?>" class="insert_color<?php echo e($b); ?>" value="<?php echo e($data->id_color); ?>">
                            <div class="list_color">
                                <div class="get_input_gradient1">
                                    <div class="input">
                                        <input type="text" data-id="<?php echo e($data->id_color); ?>" data-menu="<?php  if(isset($id_menu_check)){echo $id_menu_check;}  ?>" name="section8_ga<?php echo e($a); ?>" class="ga<?php echo e($a); ?> section8_ga<?php echo e($a); ?>" value="<?php echo e($data->hex); ?>" placeholder="Nhập mã màu" />
                                    </div>
                                    <div class="input">
                                        <span>+</span>
                                    </div>
                                    <div class="input">
                                        <input type="text" data-id="<?php echo e($data->id_color); ?>" data-menu="<?php  if(isset($id_menu_check)){echo $id_menu_check;}  ?>" name="section8_ga<?php echo e($a+1); ?>" class="ga<?php echo e($a+1); ?> section8_ga<?php echo e($a); ?>" value="<?php echo e($data->hex2); ?>" placeholder="Nhập mã màu" />
                                    </div>
                                </div>
                                <div class="list">
                                    <?php if(isset($data->hex) && isset($data->hex2)): ?>
                                        <div class="color_item get_gar<?php echo e($b); ?>" style="background-image: linear-gradient(to right, <?php echo e($data->hex); ?>, <?php echo e($data->hex2); ?>);"></div>
                                    <?php else: ?>
                                        <div class="color_item get_gar<?php echo e($b); ?>" style="background-image: linear-gradient(to right, #7b400a, #f67f13);"></div>
                                    <?php endif; ?>
                                </div>
                                <div class="info">
                                    <ul>
                                        <?php if(isset($data->rgb)): ?>
                                            <li>RGB: <?php echo e($data->rgb); ?></li>
                                        <?php else: ?>
                                            <li>RGB: 240   131  0</li>
                                        <?php endif; ?>

                                        <?php if(isset($data->cmyk)): ?>
                                            <li>CMYK: <?php echo e($data->cmyk); ?></li>
                                        <?php else: ?>
                                            <li>CMYK: 0   57    100    0</li>
                                        <?php endif; ?>

                                        <?php if(isset($data->hex)): ?>
                                            <li>HEX CODE: <?php echo e($data->hex); ?></li>
                                        <?php else: ?>
                                            <li>HEX CODE: #F08300</li>
                                        <?php endif; ?>
                                    </ul>
                                    <input type="hidden" name="section8_rgb<?php echo e($a); ?>" class="section8_rgb<?php echo e($a); ?>"/>
                                    <input type="hidden" name="section8_cmyk<?php echo e($a); ?>" class="section8_cmyk<?php echo e($a); ?>"/>
                                    <div class="flex-grow"></div>
                                    <ul>
                                        <?php if(isset($data->rgb2)): ?>
                                            <li>RGB: <?php echo e($data->rgb2); ?></li>
                                        <?php else: ?>
                                            <li>RGB: 240   131  0</li>
                                        <?php endif; ?>

                                        <?php if(isset($data->cmyk2)): ?>
                                            <li>CMYK: <?php echo e($data->cmyk2); ?></li>
                                        <?php else: ?>
                                            <li>CMYK: 0   57    100    0</li>
                                        <?php endif; ?>

                                        <?php if(isset($data->hex2)): ?>
                                            <li>HEX CODE: <?php echo e($data->hex2); ?></li>
                                        <?php else: ?>
                                            <li>HEX CODE: #F08300</li>
                                        <?php endif; ?>
                                    </ul>
                                    <input type="hidden" name="section8_rgb<?php echo e($a+1); ?>" class="section8_rgb<?php echo e($a+1); ?>"/>
                                    <input type="hidden" name="section8_cmyk<?php echo e($a+1); ?>" class="section8_cmyk<?php echo e($a+1); ?>"/>
                                </div>
                            </div>
                            <?php 
                                $a += 1;
                             ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>



