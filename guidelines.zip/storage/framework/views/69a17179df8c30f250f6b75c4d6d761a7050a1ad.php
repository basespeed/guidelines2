<?php echo $__env->make('base.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page_404">
    <div class="insider">
        <img src="images/logo.png" alt="saokim" />
        <h1>Trang không tồn tại !</h1>
    </div>
</div>
<?php echo $__env->make('base.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
