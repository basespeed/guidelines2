<?php echo $__env->make('base.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php 
    function getLayout($layout){
        switch ($layout) {
            case "1":
                include "resources/views/layout/view/layout1.blade.php";
                break;
            case "2":
                include "resources/views/layout/view/layout2.blade.php";
                break;
            case "3":
                include "resources/views/layout/view/layout3.blade.php";
                break;
            case "4":
                include "resources/views/layout/view/layout4.blade.php";
                break;
            case "5":
                include "resources/views/layout/view/layout5.blade.php";
                break;
            case "6":
                include "resources/views/layout/view/layout6.blade.php";
                break;
            case "7":
                include "resources/views/layout/view/layout7.blade.php";
                break;
            case "8":
                include "resources/views/layout/view/layout8.blade.php";
                break;
            case "9":
                include "resources/views/layout/view/layout9.blade.php";
                break;
            case "10":
                include "resources/views/layout/view/layout10.blade.php";
                break;
            case "11":
                include "resources/views/layout/view/layout11.blade.php";
                break;
            case "12":
                include "resources/views/layout/view/layout12.blade.php";
                break;
            case "13":
                include "resources/views/layout/view/layout13.blade.php";
                break;
            case "14":
                include "resources/views/layout/view/layout14.blade.php";
                break;
            case "15":
                include "resources/views/layout/view/layout15.blade.php";
                break;
            case "16":
                include "resources/views/layout/view/layout16.blade.php";
                break;
            case "17":
                include "resources/views/layout/view/layout17.blade.php";
                break;
            case "18":
                include "resources/views/layout/view/layout18.blade.php";
                break;
            default:
                include "resources/views/layout/view/layout1.blade.php";
        }
    }
 ?>

<div class="fullpage_fix">
    <div class="sidebar menu_admin">
        <div class="logo">
            <?php $__currentLoopData = $data_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->image_type == 0): ?>
                    <a href="<?php echo e(asset($slug)); ?>"><img src="<?php echo e(url('/').'/public'.$data->image_url); ?>" alt="logo" /></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <ul id="menu">
            <?php  $count = 0;$count2 = 0;  ?>
            <?php $__currentLoopData = $data_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  $count++;$count2++;  ?>
                <li data-menuanchor="sec<?php echo e($count); ?>" data-id="<?php echo e($menu->id_menu); ?>"><a href="<?php echo e(asset($slug.'#sec'.$count)); ?>"><?php echo e($menu->name_menu); ?></a>
                    <?php 
                        $id_menu = $menu->id_menu;
                        $count_child = $count;
                     ?>
                    <ul>
                    <?php $__currentLoopData = $data_menu_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($child->id_menu_menu_child == $id_menu): ?>
                            <?php 
                                $count_child++;
                             ?>
                            <li data-menuanchor="sec<?php echo e($count_child); ?>"><a href="<?php echo e(asset($slug.'#sec'.$count_child)); ?>"><?php echo e($child->name_menu_child); ?></a>
                                <?php if(Session::has('session_guideline_admin')): ?>
                                <div class="list_edit">
                                    <div class="edit">
                                        <a href="<?php echo e(asset('edit/guidelines/'.$slug)); ?>#sec<?php echo e($count_child); ?>"><img src="images/writing.png" alt="edit"></a>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $count = $count_child;
                     ?>
                    </ul>

                    <?php if(Session::has('session_guideline_admin')): ?>
                    <div class="list_edit">
                        <div class="edit">
                            <a href="<?php echo e(asset('edit/guidelines/'.$slug)); ?>#sec<?php echo e($count2); ?>"><img src="images/writing.png" alt="edit"></a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <i class="fa fa-caret-down" aria-hidden="true"></i>
                </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div class="copyright_menu">
            <p>Created by Saokim | Copyright 2019</p>
        </div>
    </div>

    <div id="fullpage">
        <?php  $count = 0;  ?>
        <?php $__currentLoopData = $data_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
                $count++;
                /*$menu->id_layout_menu*/
                $id_menu = $menu->id_menu;
                $count_child = $count;
                $check_menu = 'image_menu';
             ?>
            <?php if($menu->id_layout_menu == 1): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 2): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 3): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 4): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 5): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 6): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout6', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 7): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout7', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 8): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout8', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 9): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout9', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 10): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout10', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 11): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout11', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 12): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout12', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 13): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout13', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 14): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout14', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 15): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout15', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 16): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout16', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 17): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout17', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php elseif($menu->id_layout_menu == 18): ?>
                <?php 
                    $id_menu_check = $menu->id_menu;
                 ?>
                <?php echo $__env->make('layout.view.layout18', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>

            <?php $__currentLoopData = $data_menu_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($child->id_menu_menu_child == $id_menu): ?>
                    <?php 
                        $count_child++;
                        $id_menu_check = $child->id_menu_child;
                        $check_menu = 'image_menu_child';
                     ?>

                    <?php if($child->id_layout_menu_child == 1): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 2): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 3): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 4): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 5): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 6): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout6', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 7): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout7', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 8): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout8', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 9): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout9', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 10): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout10', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 11): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout11', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 12): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout12', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 13): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout13', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 14): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout14', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 15): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout15', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 16): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout16', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 17): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout17', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php elseif($child->id_layout_menu_child == 18): ?>
                        <?php 
                            $id_menu_check = $child->id_menu_child;
                         ?>
                        <?php echo $__env->make('layout.view.layout18', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php 
                $count = $count_child;
             ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php echo $__env->make('backend.slt_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('backend.edit_guide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('base.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
