<section class="section section4">
    <div class="in">
        <h2>0.2 <p>Logo chuẩn</p></h2>
        <div class="list_logo">
            <?php $__currentLoopData = $data_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->layout_image == 4 && $data->$check_menu == $id_menu_check): ?>

                    <?php if($data->image_order == 1): ?>
                        <?php 
                        $image1 = url('/').'/public'.$data->image_url;
                         ?>
                    <?php elseif($data->image_order == 2): ?>
                        <?php 
                        $vector1 = url('/').'/public'.$data->image_url;
                         ?>
                    <?php elseif($data->image_order == 3): ?>
                        <?php 
                        $image_zip1 = url('/').'/public'.$data->image_url;
                         ?>
                    <?php elseif($data->image_order == 4): ?>
                        <?php 
                        $image2 = url('/').'/public'.$data->image_url;
                         ?>
                    <?php elseif($data->image_order == 5): ?>
                        <?php 
                        $vector2 = url('/').'/public'.$data->image_url;
                         ?>
                    <?php elseif($data->image_order == 6): ?>
                        <?php 
                        $image_zip2 = url('/').'/public'.$data->image_url;
                         ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="item">
                <div class="insider">
                    <div class="logo">
                        <?php if(isset($image1)): ?>
                        <img src="<?php echo e($image1); ?>" width="448px" alt="logo"/>
                        <?php else: ?>
                        <img src="images/logo4.png" alt="logo"/>
                        <?php endif; ?>
                    </div>
                    <h3>Logo định dạng ngang</h3>

                    <?php if(isset($vector1)): ?>
                    <a href="<?php echo e($vector1); ?>" class="btn1">Dowload file vector</a>
                    <?php else: ?>
                    <a href="#" class="btn1">Dowload file vector</a>
                    <?php endif; ?>

                    <?php if(isset($image_zip1)): ?>
                    <a href="<?php echo e($image_zip1); ?>" class="btn2">Dowload hình ảnh</a>
                    <?php else: ?>
                    <a href="#" class="btn2">Dowload hình ảnh</a>
                    <?php endif; ?>

                </div>
            </div>

            <div class="item">
                <div class="insider">
                    <div class="logo">
                        <?php if(isset($image2)): ?>
                        <img src="<?php echo e($image2); ?>" width="286px" alt="logo"/>
                        <?php else: ?>
                        <img src="images/logo5.png" width="286px" alt="logo"/>
                        <?php endif; ?>
                    </div>
                    <h3>Logo định dạng ngang</h3>

                    <?php if(isset($vector2)): ?>
                    <a href="<?php echo e($vector2); ?>" class="btn1">Dowload file vector</a>
                    <?php else: ?>
                    <a href="#" class="btn1">Dowload file vector</a>
                    <?php endif; ?>

                    <?php if(isset($image_zip2)): ?>
                    <a href="<?php echo e($image_zip2); ?>" class="btn2">Dowload hình ảnh</a>
                    <?php else: ?>
                    <a href="#" class="btn2">Dowload hình ảnh</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>