<section data-id="<?php  if(isset($id_menu_check)){echo $id_menu_check;}  ?>" class="section section5">
    <div class="in">
        <h2>0.3 <p>Ý nghĩa logo</p></h2>

        <?php $__currentLoopData = $data_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($data->layout_image == 5  && $data->$check_menu == $id_menu_check): ?>
                <?php if($data->image_type == 1): ?>
                    <?php 
                        $url = $data->image_url;
                        $id = $data->id_image;
                     ?>
                <?php endif; ?>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $data_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($data->layout_info == 5): ?>
                <?php 
                    $id_content = $data->id_info;
                 ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(isset($url)): ?>
            <button class="btn_ground_idea border-hide" type="button">
                <img src="<?php echo e(url('/').'/public'.$url); ?>" alt="icon" />
                <input type="file" data-id="<?php echo e($id); ?>" data-menu="<?php  if(isset($id_menu_check)){echo $id_menu_check;}  ?>" name="section5_upload_background2" class="upload_background section5_upload_background2"/>
                <i class="fa fa-times" aria-hidden="true"></i>
            </button>
        <?php else: ?>
            <button class="btn_ground_idea" type="button">
                <img src="images/upto4.png" alt="icon" />
                <input type="file" data-id="<?php echo e($id); ?>" data-menu="<?php  if(isset($id_menu_check)){echo $id_menu_check;}  ?>" name="section5_upload_background2" class="upload_background section5_upload_background2"/>
                <i class="fa fa-times" aria-hidden="true"></i>
            </button>
        <?php endif; ?>

        <textarea class="text_idea section5_text" data-id="<?php echo e($id_content); ?>" data-menu="<?php  if(isset($id_menu_check)){echo $id_menu_check;}  ?>" name="section5_text" placeholder="Nội dung" style="text-align: left;"><?php $__currentLoopData = $data_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(!empty($data->content_info)): ?><?php echo e($data->content_info); ?><?php endif; ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>

        <input type="hidden" name="check_type_menu_layout5" class="check_type_menu_layout5" value="<?php echo e($check_menu); ?>">
    </div>
</section>