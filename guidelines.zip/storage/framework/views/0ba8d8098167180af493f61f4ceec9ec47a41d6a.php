<?php echo $__env->make('base.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<form action="<?php echo e(Route('insertGuidelinesDetails')); ?>" method="post" enctype="multipart/form-data">
    <?php if(isset($id_project)): ?>
        <input type="hidden" name="id_project" class="id_project" value="<?php echo e($id_project); ?>">
    <?php endif; ?>
    <?php if(isset($slug_project_name)): ?>
    <input type="hidden" name="slug_project" class="slug_project" value="<?php echo e($slug_project_name); ?>">
    <?php endif; ?>
    <?php if(isset($id_logo)): ?>
    <input type="hidden" name="id_logo" class="id_logo" value="<?php echo e($id_logo); ?>">
    <?php endif; ?>

    <div class="fullpage_fix">
        <div class="sidebar menu_admin">
            <?php $__currentLoopData = $data_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->image_type == 0): ?>
                    <?php if(!empty($data->image_url)): ?>
                        <div class="logo">
                            <div class="img"><img src="<?php echo e(url('/').'/public'.$data->image_url); ?>" alt="logo" /></div>
                            <div class="close_logo_admin show" data-id="<?php echo e($id); ?>"><i class="fa fa-times" aria-hidden="true"></i></div>
                            <input type="file" class="upload_logo" name="upload_logo_menu"/>
                        </div>
                    <?php else: ?>
                        <div class="logo">
                            <div class="img"><img src="images/upload4.png" alt="logo" /></div>
                            <div class="close_logo_admin" data-id="<?php echo e($id); ?>"><i class="fa fa-times" aria-hidden="true"></i></div>
                            <input type="file" class="upload_logo" name="upload_logo_menu"/>
                        </div>
                    <?php endif; ?>
                    <input type="hidden" name="id_logo" class="id_logo" value="<?php echo e($data->id_image); ?>">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <br/>
            

            <h3 style="margin-bottom: -10px;">Guidelines module add</h3>
            <ul id="menu" class="">
                <?php  $count = 0;  ?>
                <?php $__currentLoopData = $data_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php  $count++;  ?>
                    <li data-menuanchor="sec<?php echo e($count); ?>" data-id="<?php echo e($menu->id_menu); ?>"><a href="<?php echo e(asset('edit/guidelines/'.$slug.'#sec'.$count)); ?>"><?php echo e($menu->name_menu); ?></a>
                        <?php 
                            $id_menu = $menu->id_menu;
                            $count_child = $count;
                         ?>
                        <ul>
                            <?php $__currentLoopData = $data_menu_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($child->id_menu_menu_child == $id_menu): ?>
                                    <?php 
                                        $count_child++;
                                     ?>
                                    <li data-menuanchor="sec<?php echo e($count_child); ?>"><a href="<?php echo e(asset('edit/guidelines/'.$slug.'#sec'.$count_child)); ?>"><?php echo e($child->name_menu_child); ?></a>
                                        <?php if(Session::has('session_guideline_admin')): ?>
                                            <div class="list_edit">
                                                <div class="edit">
                                                    <a href="<?php echo e(asset('edit/guidelines/'.$slug)); ?>#sec<?php echo e($count_child); ?>"><img src="images/writing.png" alt="edit"></a>
                                                </div>
                                                <div class="del" data-parent="child" data-id="<?php echo e($child->id_menu_child); ?>">
                                                    <a href="<?php echo e(asset('edit/guidelines/'.$slug)); ?>#sec<?php echo e($count_child); ?>"><img src="images/rubbish-bin.png" alt="delete"></a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $count = $count_child;
                             ?>
                        </ul>

                        <?php if(Session::has('session_guideline_admin')): ?>
                            <div class="list_edit">
                                <div class="edit">
                                    <a href="<?php echo e(asset('edit/guidelines/'.$slug)); ?>#sec<?php echo e($count); ?>"><img src="images/writing.png" alt="edit"></a>
                                </div>
                                <div class="del" data-parent="parent" data-id="<?php echo e($menu->id_menu); ?>">
                                    <a href="<?php echo e(asset('edit/guidelines/'.$slug)); ?>#sec<?php echo e($count); ?>"><img src="images/rubbish-bin.png" alt="delete"></a>
                                </div>
                            </div>
                        <?php endif; ?>
                        <i class="fa fa-caret-down" aria-hidden="true"></i>
                    </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div class="btn_menu">
                <button type="button" class="btn_send_menu_admin">+ Create new item</button>
            </div>

            
        </div>

        <div id="fullpage" class="fullpage_admin fullpage_new">
            <?php  $count = 0;  ?>
            <?php $__currentLoopData = $data_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $count++;
                    /*$menu->id_layout_menu*/
                    $id_menu = $menu->id_menu;
                    $count_child = $count;
                    $check_menu = 'image_menu';
                 ?>

                <?php if($menu->id_layout_menu == 1): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 2): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 3): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 4): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 5): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 6): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout6', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 7): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout7', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 8): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout8', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 9): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout9', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 10): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout10', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 11): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout11', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 12): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout12', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 13): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout13', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 14): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout14', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 15): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout15', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 16): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout16', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 17): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout17', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php elseif($menu->id_layout_menu == 18): ?>
                    <?php 
                        $id_menu_check = $menu->id_menu;
                     ?>
                    <?php echo $__env->make('layout.edit.layout18', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>

                <?php $__currentLoopData = $data_menu_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($child->id_menu_menu_child == $id_menu): ?>
                        <?php 
                            $count_child++;
                            $check_menu = 'image_menu_child';
                         ?>
                        
                        <?php if($child->id_layout_menu_child == 1): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 2): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 3): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 4): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 5): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 6): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout6', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 7): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout7', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 8): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout8', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 9): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout9', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 10): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout10', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 11): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout11', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 12): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout12', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 13): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout13', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 14): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout14', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 15): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout15', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 16): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout16', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 17): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout17', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php elseif($child->id_layout_menu_child == 18): ?>
                            <?php 
                                $id_menu_check = $child->id_menu_child;
                             ?>
                            <?php echo $__env->make('layout.edit.layout18', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $count = $count_child;
                 ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php echo $__env->make('backend.slt_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('backend.edit_guide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo e(csrf_field()); ?>


</form>
<?php echo $__env->make('base.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

