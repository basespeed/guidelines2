;jQuery(function($) {
	$.colorpicker.regional['de'] = {
		ok:				'OK',
		cancel:			'Abbrechen',
		none:			'Keine',
		button:			'Farbe',
		title:			'Wähle eine Farbe',
		transparent:	'Transparent',
		hsvH:			'H',
		hsvS:			'S',
		hsvV:			'V',
		rgbR:			'R',
		rgbG:			'G',
		rgbB:			'B',
		labL:			'L',
		labA:			'a',
		labB:			'b',
		hslH:			'H',
		hslS:			'S',
		hslL:			'L',
		cmykC:			'C',
		cmykM:			'M',
		cmykY:			'Y',
		cmykK:			'K',
		alphaA:			'A'
	};
});