;
jQuery(function ($) {
	$.colorpicker.regional['el'] = {
		"alphaA": "A",
		"button": "Χρώμα",
		"cancel": "Άκυρο",
		"cmykC": "C",
		"cmykK": "K",
		"cmykM": "M",
		"cmykY": "Y",
		"hslH": "H",
		"hslL": "L",
		"hslS": "S",
		"hsvH": "H",
		"hsvS": "S",
		"hsvV": "V",
		"labA": "a",
		"labB": "b",
		"labL": "L",
		"none": "Κανένα",
		"ok": "Επιβεβαίωση",
		"rgbB": "B",
		"rgbG": "G",
		"rgbR": "Κ",
		"title": "Επιλέξτε χρώμα",
		"transparent": "Διαφάνεια"
	};
});