@include('base.header')
<div class="page_404">
    <div class="insider">
        <img src="images/logo.png" alt="saokim" />
        <h1>Trang không tồn tại !</h1>
    </div>
</div>
@include('base.footer')
