<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
<script src="js/fullpage.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.24/jquery-ui.js"></script>
<script src="js/jquery.colorpicker.js"></script>
<script src="i18n/jquery.ui.colorpicker-nl.js"></script>
<script src="swatches/jquery.ui.colorpicker-pantone.js"></script>
<script src="swatches/jquery.ui.colorpicker-crayola.js"></script>
<script src="swatches/jquery.ui.colorpicker-ral-classic.js"></script>
<script src="swatches/jquery.ui.colorpicker-x11.js"></script>
<script src="swatches/jquery.ui.colorpicker-copic.js"></script>
<script src="swatches/jquery.ui.colorpicker-prismacolor.js"></script>
<script src="swatches/jquery.ui.colorpicker-isccnbs.js"></script>
<script src="swatches/jquery.ui.colorpicker-din6164.js"></script>
{{--<script src="parts/jquery.ui.colorpicker-rgbslider.js"></script>--}}
{{--<script src="parts/jquery.ui.colorpicker-memory.js"></script>--}}
{{--<script src="parts/jquery.ui.colorpicker-swatchesswitcher.js"></script>--}}
<script src="parsers/jquery.ui.colorpicker-cmyk-parser.js"></script>
<script src="parsers/jquery.ui.colorpicker-cmyk-percentage-parser.js"></script>
<script src="js/js.js"></script>
</body>
</html>
