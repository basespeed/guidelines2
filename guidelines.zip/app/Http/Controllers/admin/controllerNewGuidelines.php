<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Carbon;

class controllerNewGuidelines extends Controller
{
    public function getEditGuidelines($slug){

        return view('backend.editGuidelines',['id'=>$slug]);
    }

    public function postNewGuidelines(Request $request){
        $projects_search = DB::table('sk_project')->Where('name_project', 'like', '%' . $request->get_invite_user_slt_project . '%')->count();
        if($request->checkbox_project == true){
            $check = 1;
        }else{
            $check = 0;
        }
        if($projects_search < 1){
            return view('backend.newGuidelines',[
                'name'=>$request->get_invite_user_slt_project,
                'invite'=>$request->get_invite_user_slt_user,
                'cate'=>$request->get_invite_user_slt_cate,
                'check'=>$check
            ]);

        }else{
            return redirect()->intended('admin')->with([
                'errors' => 'Project đã tồn tại !',
            ]);
        }
    }
}
