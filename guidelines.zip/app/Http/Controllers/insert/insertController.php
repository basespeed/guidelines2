<?php

namespace App\Http\Controllers\insert;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Session;

class insertController extends Controller
{
    public function postInsertGuidelinesDetails(Request $request){
        //convert string to slug
        function to_slug($str)
        {
            $str = trim(mb_strtolower($str));
            $str = preg_replace('/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/', 'a', $str);
            $str = preg_replace('/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/', 'e', $str);
            $str = preg_replace('/(ì|í|ị|ỉ|ĩ)/', 'i', $str);
            $str = preg_replace('/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/', 'o', $str);
            $str = preg_replace('/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/', 'u', $str);
            $str = preg_replace('/(ỳ|ý|ỵ|ỷ|ỹ)/', 'y', $str);
            $str = preg_replace('/(đ)/', 'd', $str);
            $str = preg_replace('/[^a-z0-9-\s]/', '', $str);
            $str = preg_replace('/([\s]+)/', '-', $str);
            return $str;
        }

        $project_id = DB::table('sk_project')->insertGetId(
            array(
                'id_layout' => 1,
                'list_invite' => $request->invite_project,
                'list_category' => $request->cate_project,
                'name_project' => $request->name_project,
                'name_create' => Session::get('session_guideline_username'),
                'status' => 1,
                'security' => $request->checkbox_project,
                'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
            )
        );

        //get slug project
        $get_slug_project = DB::table('dm_project')->where('project_id', $request->name_project)->get();

        foreach ($get_slug_project as $get_project) {
            $name_project = $get_project->project_name;
        }

        $slug_project_name = to_slug($name_project);
        $update = DB::table('sk_project')->where('name_project', $request->name_project)->update(['slug' => to_slug($name_project)]);


        //insert logo sidebar project
        if ($request->hasFile('upload_logo_menu')) {
            $file = $request->upload_logo_menu;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/images/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/images/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - logo
             * 2 - background
             * 3 - vector
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 0,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_url' => $folder_image,
                    'image_type' => 0,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }


        //insert menu default
        $name_project = $request->name_project;
        $cate_project = $request->cate_project;
        $cate_project = $request->cate_project;
        $checkbox_project = $request->checkbox_project;

        $insert_default = DB::table('sk_menu')->insertGetId(array('name_menu' => 'Giới thiệu', 'id_project_menu' => $project_id, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default = DB::table('sk_menu')->insertGetId(array('name_menu' => 'Thông tin quan trọng', 'id_project_menu' => $project_id, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_parent = DB::table('sk_menu')->insertGetId(array('name_menu' => 'Logo guidelines', 'id_project_menu' => $project_id, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));

        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Logo', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Ý nghĩa logo', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Tỷ lệ đồ họa', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Màu sắc', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Màu hạn chế', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Dải màu hỗ trợ', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Font chữ sử dụng', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Không gian trống tối thiểu', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Các dạng thức sử dụng logo', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Kích thước logo tối thiểu', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Thi công dạng nổi, dạng chìm', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Đặt trên nền ảnh', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Trường hợp tránh sử dụng', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));
        $insert_default_child = DB::table('sk_menu_child')->insertGetId(array('name_menu_child' => 'Phối cảnh logo', 'id_project_menu_child' => $project_id,'id_menu_menu_child'=>$insert_default_parent, 'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),));

        /*layout1*/
        if ($request->hasFile('section1_upload_background')) {
            $file = $request->section1_upload_background;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/images/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/images/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - logo
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 1,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_url' => $folder_image,
                    'image_type' => 2,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }
        /*layout3*/
        if ($request->hasFile('section3_upload_background')) {
            $file = $request->section3_upload_background;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/images/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/images/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - images
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 3,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_url' => $folder_image,
                    'image_type' => 2,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        /*layout4*/
        //img1
        if ($request->hasFile('section4_upload_background1')) {
            $file = $request->section4_upload_background1;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/images/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/images/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 4,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_url' => $folder_image,
                    'image_type' => 1,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }
        //zip vector
        if ($request->hasFile('section4_file_vector1')) {
            $file = $request->section4_file_vector1;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/zip/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/zip/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 4,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_zip' => $folder_image,
                    'image_type' => 4,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }
        //zip image1
        if ($request->hasFile('section4_file_img1')) {
            $file = $request->section4_file_img1;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/zip/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/zip/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 4,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_zip' => $folder_image,
                    'image_type' => 4,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        //img2
        if ($request->hasFile('section4_upload_background2')) {
            $file = $request->section4_upload_background2;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/images/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/images/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 4,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_url' => $folder_image,
                    'image_type' => 1,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        //zip vector
        if ($request->hasFile('section4_file_vector2')) {
            $file = $request->section4_file_vector2;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/zip/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/zip/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 4,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_zip' => $folder_image,
                    'image_type' => 4,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        //zip image
        if ($request->hasFile('section4_file_img2')) {
            $file = $request->section4_file_img2;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/zip/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/zip/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 4,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_zip' => $folder_image,
                    'image_type' => 4,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        /*layout5*/
        if ($request->hasFile('section5_upload_background2')) {
            $file = $request->section5_upload_background2;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/images/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/images/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - images
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 5,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_url' => $folder_image,
                    'image_type' => 1,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );

            $insert_info = DB::table('sk_info')->insertGetId(
                array(
                    'id_project_info' => $project_id,
                    'layout_info' => 5,
                    'content_info' => $request->section5_text,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        /*layout6*/
        if ($request->hasFile('section6_upload_background2')) {
            $file = $request->section6_upload_background2;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/images/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/images/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - images
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert = DB::table('sk_image')->insertGetId(
                array(
                    'id_project_image' => $project_id,
                    'layout_image' => 6,
                    'image_name' => $file_name,
                    'image_mime' => $mime_file,
                    'image_url' => $folder_image,
                    'image_type' => 1,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        /*layout7*/
        $insert_color = DB::table('sk_color')->insertGetId(
            array(
                'id_project_color' => $project_id,
                'layout_color' => 7,
                'hex' => $request->section7_color1,
                'rgb' => $request->section7_rgb1,
                'cmyk' => $request->section7_cmyk1,
                'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
            )
        );
        $insert_color = DB::table('sk_color')->insertGetId(
            array(
                'id_project_color' => $project_id,
                'layout_color' => 7,
                'hex' => $request->section7_color2,
                'rgb' => $request->section7_rgb2,
                'cmyk' => $request->section7_cmyk2,
                'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
            )
        );

        /*layout8*/
        $insert_color = DB::table('sk_color')->insertGetId(
            array(
                'id_project_color' => $project_id,
                'layout_color' => 8,
                'hex' => $request->section8_ga1,
                'rgb' => $request->section8_rgb1,
                'cmyk' => $request->section8_cmyk1,
                'hex2' => $request->section8_ga2,
                'rgb2' => $request->section8_rgb2,
                'cmyk2' => $request->section8_cmyk2,
                'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
            )
        );
        $insert_color = DB::table('sk_color')->insertGetId(
            array(
                'id_project_color' => $project_id,
                'layout_color' => 8,
                'hex' => $request->section8_ga3,
                'rgb' => $request->section8_rgb3,
                'cmyk' => $request->section8_cmyk3,
                'hex2' => $request->section8_ga4,
                'rgb2' => $request->section8_rgb4,
                'cmyk2' => $request->section8_cmyk4,
                'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
            )
        );

        /*layout9*/
        if ($request->hasFile('section9_upload_font_th')) {
            $file = $request->section9_upload_font_th;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/zip/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/zip/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert_font = DB::table('sk_font')->insertGetId(
                array(
                    'id_project_font' => $project_id,
                    'layout_font' => 9,
                    'font' => $folder_image,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        if ($request->hasFile('section9_upload_font_bt')) {
            $file = $request->section9_upload_font_bt;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/zip/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/zip/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert_font = DB::table('sk_font')->insertGetId(
                array(
                    'id_project_font' => $project_id,
                    'layout_font' => 9,
                    'font' => $folder_image,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        if ($request->hasFile('section9_upload_font_vb')) {
            $file = $request->section9_upload_font_vb;
            //name file
            $file_name = uniqid() . '_' . $file->getClientOriginalName();
            //mime file
            $mime_file = $file->getClientOriginalExtension();
            //folder save image
            $folder_image = '/zip/' . $slug_project_name.'/'.$file_name;
            //url file
            $url_file = $file->getRealPath();
            //size file
            $size_file = $file->getSize();
            //type file
            $type_file = $file->getMimeType();

            //create folder save images
            $path = public_path('/zip/' . $slug_project_name);

            //check isset folder
            if (!File::isDirectory($path)) {
                File::makeDirectory($path, 0777, true, true);
            }

            //move images to folder
            $file->move($path, $file_name);

            //query insert
            /*
             * Type image
             * 0 - default
             * 1 - image
             * 2 - background
             * 3 - vector
             * 4 - zip
             * */
            $insert_font = DB::table('sk_font')->insertGetId(
                array(
                    'id_project_font' => $project_id,
                    'layout_font' => 9,
                    'font' => $folder_image,
                    'created_at' => Carbon::now('Asia/Ho_Chi_Minh'),
                )
            );
        }

        return redirect()->intended('/guidelines/'.$slug_project_name);
    }
}
